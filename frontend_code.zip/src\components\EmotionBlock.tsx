import React from "react";

export type EmotionType =
  // High Energy, Pleasant
  | "Excited"
  | "Focused"
  | "Happy"
  | "Proud"
  | "Energetic"
  | "Inspired"
  | "Playful"
  | "Motivated"
  | "Euphoric"
  | "Empowered"
  | "Confident"
  // High Energy, Unpleasant
  | "Anxious"
  | "Stressed"
  | "Frustrated"
  | "Angry"
  | "Overwhelmed"
  | "Panicked"
  | "Irritated"
  | "Jittery"
  | "Furious"
  | "Restless"
  | "Defensive"
  // Low Energy, Pleasant
  | "Calm"
  | "Relaxed"
  | "Peaceful"
  | "Grateful"
  | "Satisfied"
  | "Serene"
  | "Content"
  | "Thoughtful"
  | "Cozy"
  | "Mellow"
  | "Reflective"
  // Low Energy, Unpleasant
  | "Tired"
  | "Bored"
  | "Sad"
  | "Lonely"
  | "Disappointed"
  | "Exhausted"
  | "Gloomy"
  | "Apathetic"
  | "Numb"
  | "Drained"
  | "Hopeless";

interface EmotionBlockProps {
  emotion: string | EmotionType;
  size?: "xs" | "sm" | "md" | "lg" | "xl";
  className?: string;
  animate?: boolean;
}

interface BlockDefinition {
  shape: "circle" | "squircle" | "diamond" | "leaf" | "star" | "pill-h" | "pill-v" | "hexagon" | "triangle" | "cross";
  colors: string; // Tailwind gradient class
  borderColors: string;
  rotation: string;
  animationClass: string;
}

export const EMOTION_BLOCK_MAP: Record<EmotionType | string, BlockDefinition> = {
  // High Energy, Pleasant (Yellows / Oranges / Violets)
  Euphoric: { colors: "from-yellow-400 via-amber-500 to-rose-500", shape: "circle", borderColors: "", rotation: "", animationClass: "" },
  Empowered: { colors: "from-amber-500 via-orange-600 to-red-600", shape: "circle", borderColors: "", rotation: "", animationClass: "" },
  Confident: { colors: "from-orange-400 via-rose-400 to-purple-500", shape: "circle", borderColors: "", rotation: "", animationClass: "" },

  Furious: { colors: "from-red-700 via-red-800 to-black", shape: "circle", borderColors: "", rotation: "", animationClass: "" },
  Restless: { colors: "from-rose-500 via-orange-500 to-amber-600", shape: "circle", borderColors: "", rotation: "", animationClass: "" },
  Defensive: { colors: "from-slate-700 via-red-900 to-rose-900", shape: "circle", borderColors: "", rotation: "", animationClass: "" },

  Cozy: { colors: "from-amber-200 via-orange-300 to-rose-300", shape: "circle", borderColors: "", rotation: "", animationClass: "" },
  Mellow: { colors: "from-teal-200 via-emerald-300 to-green-400", shape: "circle", borderColors: "", rotation: "", animationClass: "" },
  Reflective: { colors: "from-indigo-300 via-purple-400 to-sky-400", shape: "circle", borderColors: "", rotation: "", animationClass: "" },

  Numb: { colors: "from-slate-400 via-slate-500 to-slate-600", shape: "circle", borderColors: "", rotation: "", animationClass: "" },
  Drained: { colors: "from-zinc-600 via-slate-700 to-slate-800", shape: "circle", borderColors: "", rotation: "", animationClass: "" },
  Hopeless: { colors: "from-blue-900 via-slate-900 to-black", shape: "circle", borderColors: "", rotation: "", animationClass: "" },

  Excited: {
    shape: "star",
    colors: "from-amber-400 via-orange-400 to-red-500",
    borderColors: "border-amber-300",
    rotation: "rotate-12",
    animationClass: "animate-pulse",
  },
  Focused: {
    shape: "diamond",
    colors: "from-purple-500 via-indigo-500 to-cyan-500",
    borderColors: "border-purple-300",
    rotation: "rotate-45",
    animationClass: "hover:scale-110",
  },
  Happy: {
    shape: "circle",
    colors: "from-yellow-300 via-amber-400 to-orange-400",
    borderColors: "border-yellow-200",
    rotation: "rotate-0",
    animationClass: "animate-bounce-slow",
  },
  Proud: {
    shape: "hexagon",
    colors: "from-orange-400 via-pink-500 to-purple-600",
    borderColors: "border-orange-300",
    rotation: "-rotate-12",
    animationClass: "hover:rotate-12",
  },
  Energetic: {
    shape: "triangle",
    colors: "from-red-500 via-orange-500 to-yellow-500",
    borderColors: "border-red-400",
    rotation: "rotate-180", // upside down sharp look
    animationClass: "animate-pulse",
  },
  Inspired: {
    shape: "star",
    colors: "from-purple-400 via-pink-400 to-amber-300",
    borderColors: "border-purple-200",
    rotation: "rotate-0",
    animationClass: "animate-pulse",
  },
  Playful: {
    shape: "circle",
    colors: "from-pink-400 via-orange-400 to-yellow-400",
    borderColors: "border-pink-300",
    rotation: "rotate-12",
    animationClass: "animate-bounce-slow",
  },
  Motivated: {
    shape: "triangle",
    colors: "from-amber-400 via-orange-500 to-rose-500",
    borderColors: "border-amber-300",
    rotation: "rotate-0",
    animationClass: "hover:scale-110",
  },

  // High Energy, Unpleasant (Reds / Roses / Pinks)
  Anxious: {
    shape: "cross",
    colors: "from-rose-400 via-pink-500 to-red-500",
    borderColors: "border-rose-300/60",
    rotation: "rotate-12",
    animationClass: "animate-wiggle",
  },
  Stressed: {
    shape: "triangle",
    colors: "from-red-600 via-rose-500 to-orange-600",
    borderColors: "border-red-500",
    rotation: "rotate-45",
    animationClass: "animate-pulse",
  },
  Frustrated: {
    shape: "pill-v",
    colors: "from-orange-600 via-red-500 to-rose-600",
    borderColors: "border-orange-500",
    rotation: "-rotate-45",
    animationClass: "hover:skew-x-6",
  },
  Angry: {
    shape: "squircle",
    colors: "from-red-700 via-rose-600 to-slate-900",
    borderColors: "border-red-500",
    rotation: "rotate-90",
    animationClass: "animate-pulse",
  },
  Overwhelmed: {
    shape: "star", // swirling look
    colors: "from-violet-600 via-pink-500 to-indigo-700",
    borderColors: "border-violet-400",
    rotation: "rotate-45",
    animationClass: "animate-spin-slow",
  },
  Panicked: {
    shape: "cross",
    colors: "from-red-500 via-pink-600 to-purple-800",
    borderColors: "border-red-400/80",
    rotation: "-rotate-12",
    animationClass: "animate-wiggle",
  },
  Irritated: {
    shape: "hexagon",
    colors: "from-orange-500 via-red-500 to-slate-800",
    borderColors: "border-orange-400/60",
    rotation: "rotate-45",
    animationClass: "hover:skew-x-6",
  },
  Jittery: {
    shape: "diamond",
    colors: "from-yellow-600 via-orange-600 to-red-700",
    borderColors: "border-yellow-400/60",
    rotation: "rotate-12",
    animationClass: "animate-pulse",
  },

  // Low Energy, Pleasant (Greens / Emeralds / Teals / Skys)
  Calm: {
    shape: "leaf",
    colors: "from-emerald-400 via-teal-500 to-sky-500",
    borderColors: "border-emerald-300/50",
    rotation: "rotate-12",
    animationClass: "animate-float",
  },
  Relaxed: {
    shape: "pill-h",
    colors: "from-teal-300 via-cyan-400 to-emerald-400",
    borderColors: "border-teal-200/50",
    rotation: "rotate-0",
    animationClass: "animate-pulse",
  },
  Peaceful: {
    shape: "circle",
    colors: "from-sky-300 via-teal-400 to-emerald-500",
    borderColors: "border-sky-200/50",
    rotation: "rotate-12",
    animationClass: "animate-float-slow",
  },
  Grateful: {
    shape: "squircle",
    colors: "from-green-400 via-emerald-400 to-yellow-300",
    borderColors: "border-green-300/50",
    rotation: "rotate-12",
    animationClass: "hover:scale-105",
  },
  Satisfied: {
    shape: "leaf",
    colors: "from-emerald-500 via-teal-600 to-cyan-600",
    borderColors: "border-emerald-400/50",
    rotation: "rotate-45",
    animationClass: "animate-pulse",
  },
  Serene: {
    shape: "leaf",
    colors: "from-sky-300 via-cyan-300 to-teal-400",
    borderColors: "border-sky-100/50",
    rotation: "-rotate-12",
    animationClass: "animate-float-slow",
  },
  Content: {
    shape: "squircle",
    colors: "from-teal-400 via-emerald-400 to-lime-300",
    borderColors: "border-teal-200/50",
    rotation: "rotate-0",
    animationClass: "animate-float",
  },
  Thoughtful: {
    shape: "diamond",
    colors: "from-indigo-400 via-sky-400 to-teal-400",
    borderColors: "border-indigo-300/40",
    rotation: "rotate-45",
    animationClass: "hover:scale-105",
  },

  // Low Energy, Unpleasant (Blues / Indigos / Slates)
  Tired: {
    shape: "pill-h",
    colors: "from-indigo-500 via-blue-500 to-slate-600",
    borderColors: "border-indigo-400/30",
    rotation: "-rotate-12",
    animationClass: "animate-float-slow",
  },
  Bored: {
    shape: "squircle",
    colors: "from-slate-500 via-indigo-400 to-slate-700",
    borderColors: "border-slate-400/40",
    rotation: "rotate-0",
    animationClass: "",
  },
  Sad: {
    shape: "circle",
    colors: "from-blue-600 via-indigo-600 to-slate-800",
    borderColors: "border-blue-400/40",
    rotation: "rotate-0",
    animationClass: "animate-float",
  },
  Lonely: {
    shape: "triangle",
    colors: "from-blue-700 via-indigo-700 to-slate-900",
    borderColors: "border-indigo-600/30",
    rotation: "rotate-180",
    animationClass: "animate-pulse",
  },
  Disappointed: {
    shape: "diamond",
    colors: "from-slate-400 via-blue-500 to-slate-600",
    borderColors: "border-slate-300/30",
    rotation: "-rotate-45",
    animationClass: "",
  },
  Exhausted: {
    shape: "pill-v",
    colors: "from-slate-700 via-slate-800 to-black",
    borderColors: "border-slate-600/30",
    rotation: "-rotate-45",
    animationClass: "animate-float-slow",
  },
  Gloomy: {
    shape: "hexagon",
    colors: "from-blue-800 via-indigo-900 to-slate-900",
    borderColors: "border-blue-700/30",
    rotation: "rotate-12",
    animationClass: "animate-float",
  },
  Apathetic: {
    shape: "pill-h",
    colors: "from-zinc-500 via-slate-600 to-zinc-700",
    borderColors: "border-zinc-400/30",
    rotation: "rotate-0",
    animationClass: "",
  },
};

const DEFAULT_BLOCK: BlockDefinition = {
  shape: "circle",
  colors: "from-slate-400 to-slate-600",
  borderColors: "border-slate-300",
  rotation: "rotate-0",
  animationClass: "",
};

export const EmotionBlock: React.FC<EmotionBlockProps> = ({
  emotion,
  size = "md",
  className = "",
  animate = true,
}) => {
  const normalizedEmotion = emotion ? emotion.trim() : "";
  const def = EMOTION_BLOCK_MAP[normalizedEmotion] || DEFAULT_BLOCK;

  // Map abstract sizes
  const sizeClasses = {
    xs: "w-4 h-4",
    sm: "w-6 h-6",
    md: "w-8 h-8",
    lg: "w-12 h-12",
    xl: "w-16 h-16",
  };

  const currentSizeClass = sizeClasses[size] || sizeClasses.md;

  return (
    <div
      title={normalizedEmotion}
      className={`relative select-none shrink-0 rounded-md shadow-sm bg-gradient-to-br ${def.colors} ${currentSizeClass} ${
        animate ? "hover:scale-110 transition-transform duration-300" : ""
      } ${className}`}
    />
  );
};
